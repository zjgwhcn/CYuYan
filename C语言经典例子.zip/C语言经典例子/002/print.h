#include "stdio.h"

void printHello(void);